package com.tejasri.service;

import com.tejasri.DTO.EventDTO;
import com.tejasri.model.Event;
import java.util.List;

public interface EventService {
    Event createEvent(Event event);
    List<Event> getAllEvents();
    List<EventDTO> getAllEventDTOs();
    Event getEventById(Long id);
    Event updateEvent(Long id, Event updatedEvent);
    boolean deleteEvent(Long id);
}
