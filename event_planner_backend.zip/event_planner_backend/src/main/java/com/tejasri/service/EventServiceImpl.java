package com.tejasri.service;

import com.tejasri.DTO.EventDTO;
import com.tejasri.DTO.UserDTO;
import com.tejasri.model.Event;
import com.tejasri.model.User;
import com.tejasri.repository.EventRepository;
import com.tejasri.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EventServiceImpl implements EventService {

    private final EventRepository eventRepo;
    private final UserRepository userRepo;

    public EventServiceImpl(EventRepository eventRepo, UserRepository userRepo) {
        this.eventRepo = eventRepo;
        this.userRepo = userRepo;
    }

    @Override
    public Event createEvent(Event event) {
        if (event.getCreatedBy() != null && event.getCreatedBy().getId() != null) {
            User user = userRepo.findById(event.getCreatedBy().getId()).orElse(null);
            event.setCreatedBy(user);
        }
        return eventRepo.save(event);
    }

    @Override
    public List<Event> getAllEvents() {
        return eventRepo.findAll();
    }

    @Override
    public List<EventDTO> getAllEventDTOs() {
        return eventRepo.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public Event getEventById(Long id) {
        return eventRepo.findById(id).orElse(null);
    }

    @Override
    public Event updateEvent(Long id, Event updatedEvent) {
        return eventRepo.findById(id).map(event -> {
            event.setTitle(updatedEvent.getTitle());
            event.setDescription(updatedEvent.getDescription());
            event.setDate(updatedEvent.getDate());
            event.setBudget(updatedEvent.getBudget());
            if (updatedEvent.getCreatedBy() != null && updatedEvent.getCreatedBy().getId() != null) {
                User user = userRepo.findById(updatedEvent.getCreatedBy().getId()).orElse(null);
                event.setCreatedBy(user);
            }
            return eventRepo.save(event);
        }).orElse(null);
    }

    @Override
    public boolean deleteEvent(Long id) {
        return eventRepo.findById(id).map(event -> {
            eventRepo.delete(event);
            return true;
        }).orElse(false);
    }

    private EventDTO convertToDTO(Event event) {
        User user = event.getCreatedBy();
        UserDTO userDTO = null;
        if (user != null) {
            userDTO = new UserDTO(user.getId(), user.getName(), user.getEmail(), user.getRole());
        }
        return new EventDTO(event.getId(), event.getTitle(), event.getDescription(), event.getDate(), event.getBudget(), userDTO);
    }
}
