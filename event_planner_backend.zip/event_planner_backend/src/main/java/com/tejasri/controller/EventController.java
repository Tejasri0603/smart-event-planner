package com.tejasri.controller;

import com.tejasri.DTO.EventDTO;
import com.tejasri.DTO.UserDTO;
import com.tejasri.model.Event;
import com.tejasri.service.EventService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/events")
//@CrossOrigin(origins = "http://localhost:3000") // For React frontend, adjust as needed
@CrossOrigin(origins = "http://localhost:5173")
public class EventController {

    private final EventService eventService;
    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @PostMapping
    public ResponseEntity<EventDTO> create(@RequestBody Event event) {
        Event saved = eventService.createEvent(event);
        return ResponseEntity.ok(mapToDTO(saved));
    }

    @GetMapping
    public ResponseEntity<List<EventDTO>> getAll() {
        return ResponseEntity.ok(eventService.getAllEventDTOs());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EventDTO> getById(@PathVariable Long id) {
        Event event = eventService.getEventById(id);
        if (event == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(mapToDTO(event));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EventDTO> update(@PathVariable Long id, @RequestBody Event updatedEvent) {
        Event updated = eventService.updateEvent(id, updatedEvent);
        if (updated == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(mapToDTO(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean deleted = eventService.deleteEvent(id);
        if (!deleted) return ResponseEntity.notFound().build();
        return ResponseEntity.noContent().build();
    }


    // Converts Entity to DTO
    private EventDTO mapToDTO(Event event) {
        if (event.getCreatedBy() == null) {
            return new EventDTO(event.getId(), event.getTitle(), event.getDescription(), event.getDate(), event.getBudget(), null);
        }
        return new EventDTO(
                event.getId(),
                event.getTitle(),
                event.getDescription(),
                event.getDate(),
                event.getBudget(),
                new UserDTO(
                        event.getCreatedBy().getId(),
                        event.getCreatedBy().getName(),
                        event.getCreatedBy().getEmail(),
                        event.getCreatedBy().getRole()
                )
        );
    }
}
