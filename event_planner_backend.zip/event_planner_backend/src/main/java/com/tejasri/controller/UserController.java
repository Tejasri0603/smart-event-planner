package com.tejasri.controller;

import com.tejasri.model.User;
import com.tejasri.repository.UserRepository;  // Your JPA repository

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")  // React dev server origin
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        // Optional: Add validation here for name/email/role (non-null)
        if(user.getName() == null || user.getEmail() == null || user.getRole() == null) {
            return ResponseEntity.badRequest().build();
        }

        User savedUser = userRepository.save(user);
        return ResponseEntity.ok(savedUser);
    }
}

