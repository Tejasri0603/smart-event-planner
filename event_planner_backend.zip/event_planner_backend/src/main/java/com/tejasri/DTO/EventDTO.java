package com.tejasri.DTO;

import java.util.Date;

public class EventDTO {
    private Long id;
    private String title;
    private String description;
    private Date date;
    private double budget;
    private UserDTO createdBy;

    public EventDTO() {}

    public EventDTO(Long id, String title, String description, Date date, double budget, UserDTO createdBy) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.date = date;
        this.budget = budget;
        this.createdBy = createdBy;
    }

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public double getBudget() { return budget; }
    public void setBudget(double budget) { this.budget = budget; }

    public UserDTO getCreatedBy() { return createdBy; }
    public void setCreatedBy(UserDTO createdBy) { this.createdBy = createdBy; }
}
